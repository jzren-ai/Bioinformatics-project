# Bioinformatics-project
A CRISPR-Cas off-target scoring demo using GC content and chromatin accessibility features
